#!/usr/bin/env python3
"""Entry point:  python organize.py --help"""
import sys

from organizer.cli import main

if __name__ == "__main__":
    sys.exit(main())
