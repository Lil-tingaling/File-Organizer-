"""Logging setup: rotating file log + console."""
from __future__ import annotations

import logging
import sys
from logging.handlers import RotatingFileHandler
from pathlib import Path

LOGGER_NAME = "organizer"


def setup_logging(log_path: Path | None, verbose: bool = False) -> logging.Logger:
    """Console shows WARNING+ (or INFO+ with verbose); the file keeps everything."""
    logger = logging.getLogger(LOGGER_NAME)
    logger.setLevel(logging.DEBUG)
    logger.propagate = False
    for handler in list(logger.handlers):  # avoid duplicate handlers on repeated calls
        handler.close()
        logger.removeHandler(handler)

    console = logging.StreamHandler(sys.stderr)
    console.setLevel(logging.INFO if verbose else logging.WARNING)
    console.setFormatter(logging.Formatter("%(levelname)s: %(message)s"))
    logger.addHandler(console)

    if log_path is not None:
        try:
            log_path.parent.mkdir(parents=True, exist_ok=True)
            fh = RotatingFileHandler(log_path, maxBytes=1_000_000, backupCount=3, encoding="utf-8")
            fh.setLevel(logging.DEBUG)
            fh.setFormatter(logging.Formatter("%(asctime)s %(levelname)-7s %(message)s"))
            logger.addHandler(fh)
        except OSError as exc:
            logger.warning("Could not open log file %s: %s (continuing without file log)", log_path, exc)
    return logger
