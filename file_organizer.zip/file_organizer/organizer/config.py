"""Configuration loading, merging and validation (standard library only)."""
from __future__ import annotations

import copy
import json
import string
from datetime import datetime
from pathlib import Path


class ConfigError(Exception):
    """Raised when the configuration is invalid."""


DEFAULT_CATEGORIES = {
    "Images": [".jpg", ".jpeg", ".png", ".gif", ".bmp", ".webp", ".svg", ".heic", ".tiff"],
    "Documents": [".pdf", ".doc", ".docx", ".txt", ".rtf", ".odt", ".md", ".ppt", ".pptx", ".xls", ".xlsx", ".csv"],
    "Videos": [".mp4", ".mkv", ".mov", ".avi", ".wmv", ".webm"],
    "Audio": [".mp3", ".wav", ".flac", ".aac", ".ogg", ".m4a"],
    "Archives": [".zip", ".rar", ".7z", ".tar", ".gz", ".bz2"],
    "Code": [".py", ".js", ".ts", ".html", ".css", ".java", ".c", ".cpp", ".json", ".sh"],
    "Installers": [".exe", ".msi", ".dmg", ".pkg", ".deb", ".apk"],
}

DEFAULTS = {
    "source": None,
    "destination": None,            # default: same as source (organize in place)
    "organize_by": "type",          # type | date | type_date
    "date_format": "%Y-%m",         # folder name used for date modes
    "recursive": False,
    "categories": DEFAULT_CATEGORIES,
    "other_folder": "Other",
    "duplicates": "move",           # move | skip
    "duplicates_folder": "Duplicates",
    "rename_pattern": None,         # e.g. "{date}_{name}"
    "ignore_patterns": [".*", "*.tmp", "*.part", "*.crdownload", "Thumbs.db", "desktop.ini"],
    "min_age_seconds": 0,           # ignore files modified more recently than this
    "log_file": None,               # default: <destination>/.organizer_history/organizer.log
    "notify": {
        "console": True,
        "email": {
            "enabled": False,
            "only_on_activity": True,
            "smtp_host": "",
            "smtp_port": 587,
            "use_tls": True,
            "username": "",
            "password_env": "ORGANIZER_SMTP_PASSWORD",  # password is read from this env variable
            "from_addr": "",
            "to_addrs": [],
        },
    },
}

ORGANIZE_BY = ("type", "date", "type_date")
DUPLICATE_MODES = ("move", "skip")
PLACEHOLDERS = ("name", "ext", "date", "counter")


def _merge(base: dict, override: dict) -> None:
    for key, value in override.items():
        if key == "categories" or not isinstance(value, dict) or not isinstance(base.get(key), dict):
            base[key] = copy.deepcopy(value)
        else:
            _merge(base[key], value)


def load_config(path=None, overrides=None) -> dict:
    """Defaults < config file < overrides (CLI). Returns a validated config."""
    cfg = copy.deepcopy(DEFAULTS)
    if path:
        try:
            data = json.loads(Path(path).expanduser().read_text(encoding="utf-8"))
        except FileNotFoundError:
            raise ConfigError(f"Config file not found: {path}")
        except (json.JSONDecodeError, OSError) as exc:
            raise ConfigError(f"Cannot read config file {path}: {exc}")
        if not isinstance(data, dict):
            raise ConfigError("Config file must contain a JSON object")
        unknown = sorted(set(data) - set(DEFAULTS))
        if unknown:
            raise ConfigError(f"Unknown config option(s): {', '.join(unknown)}")
        _merge(cfg, data)
    if overrides:
        _merge(cfg, overrides)
    return validate(cfg)


def _folder_name(value, what: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ConfigError(f"{what} must be a non-empty string")
    if "/" in value or "\\" in value or value in (".", ".."):
        raise ConfigError(f"{what} {value!r} must be a simple folder name")
    return value


def validate(cfg: dict) -> dict:
    if not cfg["source"]:
        raise ConfigError("No source folder given (use the SOURCE argument or 'source' in the config file)")
    source = Path(str(cfg["source"])).expanduser().resolve()
    if not source.is_dir():
        raise ConfigError(f"Source folder does not exist: {source}")
    dest = Path(str(cfg["destination"])).expanduser().resolve() if cfg["destination"] else source
    if dest.exists() and not dest.is_dir():
        raise ConfigError(f"Destination is not a folder: {dest}")
    cfg["source"], cfg["destination"] = source, dest

    if cfg["organize_by"] not in ORGANIZE_BY:
        raise ConfigError(f"organize_by must be one of {ORGANIZE_BY}")
    if cfg["duplicates"] not in DUPLICATE_MODES:
        raise ConfigError(f"duplicates must be one of {DUPLICATE_MODES}")
    if not isinstance(cfg["recursive"], bool):
        raise ConfigError("recursive must be true or false")

    # categories
    cats = cfg["categories"]
    if not isinstance(cats, dict) or not cats:
        raise ConfigError("categories must be a non-empty object of {folder: [extensions]}")
    seen, normalized = {}, {}
    for name, exts in cats.items():
        _folder_name(name, "category name")
        if not isinstance(exts, list):
            raise ConfigError(f"Extensions for category {name!r} must be a list")
        clean = []
        for ext in exts:
            if not isinstance(ext, str) or not ext.startswith(".") or len(ext) < 2:
                raise ConfigError(f"Invalid extension {ext!r} in {name!r} (must look like '.jpg')")
            ext = ext.lower()
            if seen.get(ext, name) != name:
                raise ConfigError(f"Extension {ext!r} appears in both {seen[ext]!r} and {name!r}")
            seen[ext] = name
            clean.append(ext)
        normalized[name] = clean
    cfg["categories"] = normalized
    _folder_name(cfg["other_folder"], "other_folder")
    _folder_name(cfg["duplicates_folder"], "duplicates_folder")
    reserved = [cfg["other_folder"], cfg["duplicates_folder"]]
    if len(set(reserved)) != 2 or set(reserved) & set(normalized):
        raise ConfigError("other_folder, duplicates_folder and category names must all be different")

    # date format
    fmt = cfg["date_format"]
    try:
        sample = datetime(2024, 1, 2).strftime(fmt)
    except (ValueError, TypeError):
        raise ConfigError(f"Invalid date_format: {fmt!r}")
    if not sample or "/" in sample or "\\" in sample or ".." in sample:
        raise ConfigError("date_format must produce a single, simple folder name (e.g. '%Y-%m')")

    # rename pattern
    pattern = cfg["rename_pattern"]
    if pattern is not None:
        try:
            fields = [f for _, f, _, _ in string.Formatter().parse(pattern) if f is not None]
        except (ValueError, AttributeError, TypeError) as exc:
            raise ConfigError(f"Invalid rename_pattern: {exc}")
        bad = [f for f in fields if f not in PLACEHOLDERS]
        if bad:
            raise ConfigError(
                f"Unknown placeholder(s) in rename_pattern: {bad}. Allowed: "
                + ", ".join("{" + p + "}" for p in PLACEHOLDERS)
            )

    if not isinstance(cfg["ignore_patterns"], list) or not all(isinstance(p, str) for p in cfg["ignore_patterns"]):
        raise ConfigError("ignore_patterns must be a list of strings")
    age = cfg["min_age_seconds"]
    if isinstance(age, bool) or not isinstance(age, (int, float)) or age < 0:
        raise ConfigError("min_age_seconds must be a number >= 0")
    if cfg["log_file"]:
        cfg["log_file"] = Path(str(cfg["log_file"])).expanduser()

    email = cfg["notify"]["email"]
    if email["enabled"]:
        missing = [k for k in ("smtp_host", "from_addr") if not email[k]]
        if missing or not email["to_addrs"]:
            raise ConfigError("Email notifications need smtp_host, from_addr and to_addrs")
        if not isinstance(email["smtp_port"], int):
            raise ConfigError("smtp_port must be an integer")
    return cfg
