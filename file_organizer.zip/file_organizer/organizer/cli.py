"""Command-line interface."""
from __future__ import annotations

import argparse
import sys

from .config import ConfigError, load_config
from .core import UndoError, organize, undo_last
from .logger import setup_logging
from .notify import notify
from .scheduler import run_every


def _positive(value: str) -> float:
    try:
        number = float(value)
    except ValueError:
        raise argparse.ArgumentTypeError(f"{value!r} is not a number")
    if number <= 0:
        raise argparse.ArgumentTypeError("must be greater than 0")
    return number


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="organize.py",
        description="Organize a messy folder: sort by type/date, rename, and move duplicates aside.",
        epilog="Exit codes: 0 = success, 1 = finished with errors, 2 = bad configuration/usage.",
    )
    p.add_argument("source", nargs="?", help="folder to organize (or set 'source' in the config file)")
    p.add_argument("-c", "--config", help="path to a JSON config file")
    p.add_argument("-d", "--destination", help="where to put organized folders (default: inside source)")
    p.add_argument("--by", dest="organize_by", choices=["type", "date", "type_date"], help="how to group files")
    p.add_argument("-r", "--recursive", action="store_true", default=None, help="also organize files in subfolders")
    p.add_argument("--rename", dest="rename_pattern", metavar="PATTERN",
                   help="rename files, e.g. '{date}_{name}' (placeholders: {name} {ext} {date} {counter})")
    p.add_argument("--duplicates", choices=["move", "skip"], help="move duplicates to a Duplicates folder, or leave them")
    p.add_argument("--min-age", dest="min_age_seconds", type=float, metavar="SECONDS",
                   help="ignore files modified more recently than this (avoids half-downloaded files)")
    p.add_argument("-n", "--dry-run", action="store_true", help="show what would happen without changing anything")
    p.add_argument("--undo", action="store_true", help="undo the most recent run")
    p.add_argument("--every", type=_positive, metavar="MINUTES", help="keep running, repeating every N minutes")
    p.add_argument("--email", action="store_true", help="send an email summary (needs the notify.email config)")
    p.add_argument("--log-file", help="log file path (default: <destination>/.organizer_history/organizer.log)")
    p.add_argument("-v", "--verbose", action="store_true", help="print every action to the console")
    return p


def _overrides(args) -> dict:
    out = {}
    for key in ("source", "destination", "organize_by", "recursive", "rename_pattern",
                "duplicates", "min_age_seconds", "log_file"):
        value = getattr(args, key)
        if value is not None:
            out[key] = value
    if args.email:
        out["notify"] = {"email": {"enabled": True}}
    return out


def main(argv=None) -> int:
    args = build_parser().parse_args(argv)
    try:
        cfg = load_config(args.config, _overrides(args))
    except ConfigError as exc:
        print(f"Configuration error: {exc}", file=sys.stderr)
        return 2

    # A dry run only writes a log file if the user asked for one explicitly.
    log_path = cfg["log_file"]
    if log_path is None and not args.dry_run:
        log_path = cfg["destination"] / ".organizer_history" / "organizer.log"
    setup_logging(log_path, verbose=args.verbose)

    if args.undo:
        try:
            result = undo_last(cfg["destination"], dry_run=args.dry_run)
        except UndoError as exc:
            print(f"Cannot undo: {exc}", file=sys.stderr)
            return 1
        notify(cfg, result)
        return 1 if result.errors else 0

    last = {}

    def job():
        last["result"] = organize(cfg, dry_run=args.dry_run)
        notify(cfg, last["result"])

    if args.every:
        run_every(args.every, job)
        return 0
    job()
    return 1 if last["result"].errors else 0
