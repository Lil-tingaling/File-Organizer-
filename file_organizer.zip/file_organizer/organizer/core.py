"""Core logic: scan -> plan -> execute, plus undo.

Safety rules:
  * files are never overwritten (name clashes get a _1, _2 ... suffix)
  * nothing is ever deleted
  * every real run writes a manifest so it can be undone
  * one bad file never stops the run; it is logged and reported
"""
from __future__ import annotations

import fnmatch
import hashlib
import json
import logging
import os
import shutil
import time
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

log = logging.getLogger("organizer")

HISTORY_DIR = ".organizer_history"
_BAD_CHARS = '/\\:*?"<>|'


class UndoError(Exception):
    """Raised when there is nothing to undo."""


@dataclass
class PlannedAction:
    src: Path
    dst: Path | None
    kind: str  # "move" | "duplicate" | "skip"
    category: str = ""
    note: str = ""


@dataclass
class Result:
    title: str = "File Organizer"
    moved_label: str = "Moved"
    dry_run: bool = False
    moved: list = field(default_factory=list)       # (src, dst)
    duplicates: list = field(default_factory=list)  # (src, dst, note)
    skipped: list = field(default_factory=list)     # (src, reason)
    errors: list = field(default_factory=list)      # (path, message)
    categories: Counter = field(default_factory=Counter)
    duration: float = 0.0

    @property
    def has_activity(self) -> bool:
        return bool(self.moved or self.duplicates or self.errors)

    def summary(self) -> str:
        mode = "DRY RUN - no files were changed" if self.dry_run else "finished"
        lines = [f"{self.title}: {mode} in {self.duration:.2f}s"]
        lines.append(f"  {self.moved_label + ':':<11} {len(self.moved)}")
        if self.title != "Undo":
            lines.append(f"  Duplicates: {len(self.duplicates)}")
            lines.append(f"  Skipped:    {len(self.skipped)}")
        lines.append(f"  Errors:     {len(self.errors)}")
        if self.categories:
            lines.append("  By category:")
            lines += [f"    {name}: {count}" for name, count in sorted(self.categories.items())]
        if self.errors:
            lines.append("  Problems:")
            lines += [f"    {Path(p).name}: {msg}" for p, msg in self.errors]
        return "\n".join(lines)


# --------------------------------------------------------------------- helpers
def _ignored(name: str, patterns) -> bool:
    return any(fnmatch.fnmatch(name.lower(), p.lower()) for p in patterns)


def _managed_names(cfg) -> set:
    return set(cfg["categories"]) | {cfg["other_folder"], cfg["duplicates_folder"]}


def is_managed_dir(path: Path, cfg) -> bool:
    """True for folders this tool creates, so recursive runs never re-process them."""
    if path.parent != cfg["destination"]:
        return False
    if path.name in _managed_names(cfg):
        return True
    if cfg["organize_by"] == "date":
        try:
            datetime.strptime(path.name, cfg["date_format"])
            return True
        except ValueError:
            return False
    return False


def file_hash(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _same_content(a: Path, b: Path) -> bool:
    try:
        return a.stat().st_size == b.stat().st_size and file_hash(a) == file_hash(b)
    except OSError:
        return False


def _unique(dst: Path, reserved: set) -> Path:
    """Return dst, or dst with _1, _2 ... if taken (on disk or earlier in this plan)."""
    candidate, n = dst, 0
    while candidate.exists() or str(candidate).lower() in reserved:
        n += 1
        candidate = dst.with_name(f"{dst.stem}_{n}{dst.suffix}")
    reserved.add(str(candidate).lower())
    return candidate


def _build_name(path: Path, mtime: float, cfg, counter: int) -> str:
    pattern = cfg["rename_pattern"]
    if not pattern:
        return path.name
    values = {
        "name": path.stem,
        "ext": path.suffix.lstrip(".").lower(),
        "date": datetime.fromtimestamp(mtime).strftime("%Y-%m-%d"),
        "counter": f"{counter:03d}",
    }
    stem = pattern.format_map(values)
    stem = "".join("_" if c in _BAD_CHARS else c for c in stem).strip().strip(".")
    return (stem or path.stem) + path.suffix


def _target_dir(category: str, mtime: float, cfg) -> Path:
    base = cfg["destination"]
    when = datetime.fromtimestamp(mtime).strftime(cfg["date_format"])
    mode = cfg["organize_by"]
    if mode == "type":
        return base / category
    if mode == "date":
        return base / when
    return base / category / when


# ------------------------------------------------------------------------ scan
def scan(cfg, result: Result) -> list:
    now = time.time()
    files = []

    def walk(directory: Path):
        try:
            entries = sorted(os.scandir(directory), key=lambda e: e.name.lower())
        except OSError as exc:
            log.error("Cannot read folder %s: %s", directory, exc)
            result.errors.append((directory, f"cannot read folder: {exc}"))
            return
        for entry in entries:
            path = Path(entry.path)
            try:
                if _ignored(entry.name, cfg["ignore_patterns"]):
                    log.debug("Ignored by pattern: %s", path)
                    continue
                if entry.is_symlink():
                    result.skipped.append((path, "symlink"))
                    continue
                if entry.is_dir(follow_symlinks=False):
                    if cfg["recursive"] and not is_managed_dir(path, cfg):
                        walk(path)
                    continue
                if not entry.is_file(follow_symlinks=False):
                    continue
                if now - entry.stat().st_mtime < cfg["min_age_seconds"]:
                    result.skipped.append((path, "modified too recently"))
                    continue
                files.append(path)
            except OSError as exc:
                log.error("Cannot inspect %s: %s", path, exc)
                result.errors.append((path, str(exc)))

    walk(cfg["source"])
    return files


# ------------------------------------------------------------------------ plan
def _find_duplicates(files, stats, result: Result) -> dict:
    """Return {duplicate_path: kept_path}. The oldest file in each group is kept."""
    by_size = defaultdict(list)
    for f in files:
        if stats[f].st_size > 0:  # empty files are not treated as duplicates
            by_size[stats[f].st_size].append(f)
    dup_of = {}
    for group in by_size.values():
        if len(group) < 2:
            continue
        by_hash = defaultdict(list)
        for f in group:
            try:
                by_hash[file_hash(f)].append(f)
            except OSError as exc:
                log.error("Cannot read %s: %s", f, exc)
                result.errors.append((f, str(exc)))
        for same in by_hash.values():
            if len(same) > 1:
                same.sort(key=lambda p: (stats[p].st_mtime, p.name.lower()))
                for dup in same[1:]:
                    dup_of[dup] = same[0]
    return dup_of


def plan(files, cfg, result: Result) -> list:
    ext_map = {ext: cat for cat, exts in cfg["categories"].items() for ext in exts}
    stats = {}
    for f in files:
        try:
            stats[f] = f.stat()
        except OSError as exc:
            result.errors.append((f, str(exc)))
    files = [f for f in files if f in stats]
    dup_of = _find_duplicates(files, stats, result)

    dups_dir = cfg["destination"] / cfg["duplicates_folder"]
    actions, reserved, counter = [], set(), 0

    def duplicate_action(src, note):
        if cfg["duplicates"] == "skip":
            return PlannedAction(src, None, "skip", note=note)
        return PlannedAction(src, _unique(dups_dir / src.name, reserved), "duplicate", note=note)

    for f in files:
        mtime = stats[f].st_mtime
        if f in dup_of:
            actions.append(duplicate_action(f, f"duplicate of {dup_of[f].name}"))
            continue
        counter += 1
        category = ext_map.get(f.suffix.lower(), cfg["other_folder"])
        dst = _target_dir(category, mtime, cfg) / _build_name(f, mtime, cfg, counter)
        if dst == f:
            actions.append(PlannedAction(f, None, "skip", note="already in place"))
        elif dst.exists() and _same_content(f, dst):
            actions.append(duplicate_action(f, f"identical to existing {dst.name}"))
        else:
            actions.append(PlannedAction(f, _unique(dst, reserved), "move", category=category))
    return actions


# --------------------------------------------------------------------- execute
def _safe_move(src: Path, dst: Path) -> None:
    if dst.exists():
        raise FileExistsError(f"refusing to overwrite {dst}")
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.move(str(src), str(dst))


def _rel(path: Path, base: Path) -> str:
    try:
        return str(path.relative_to(base))
    except ValueError:
        return str(path)


def _write_manifest(dest: Path, moves: list) -> None:
    try:
        hist = dest / HISTORY_DIR
        hist.mkdir(parents=True, exist_ok=True)
        name = datetime.now().strftime("run_%Y%m%d_%H%M%S_%f.json")
        payload = {"created": datetime.now().isoformat(timespec="seconds"), "moves": moves}
        (hist / name).write_text(json.dumps(payload, indent=2), encoding="utf-8")
    except OSError as exc:
        log.error("Could not write undo manifest: %s (this run cannot be undone)", exc)


def execute(actions, cfg, result: Result) -> None:
    prefix = "[DRY-RUN] " if result.dry_run else ""
    done = []
    for a in actions:
        if a.kind == "skip":
            result.skipped.append((a.src, a.note))
            log.info("%sSKIP %s (%s)", prefix, a.src.name, a.note)
            continue
        try:
            if not result.dry_run:
                _safe_move(a.src, a.dst)
        except (OSError, shutil.Error) as exc:
            result.errors.append((a.src, f"{type(exc).__name__}: {exc}"))
            log.error("Could not move %s -> %s: %s", a.src, a.dst, exc)
            continue
        target = _rel(a.dst, cfg["destination"])
        if a.kind == "duplicate":
            result.duplicates.append((a.src, a.dst, a.note))
            log.info("%sDUPLICATE %s -> %s (%s)", prefix, a.src.name, target, a.note)
        else:
            result.moved.append((a.src, a.dst))
            result.categories[a.category] += 1
            log.info("%sMOVE %s -> %s", prefix, a.src.name, target)
        done.append({"src": str(a.src), "dst": str(a.dst)})
        if not result.dry_run:
            _prune_empty(a.src.parent, cfg["source"])  # only removes folders our moves emptied
    if done and not result.dry_run:
        _write_manifest(cfg["destination"], done)


def organize(cfg, dry_run: bool = False) -> Result:
    start = time.perf_counter()
    result = Result(dry_run=dry_run)
    log.info("Starting run: source=%s destination=%s mode=%s", cfg["source"], cfg["destination"], cfg["organize_by"])
    files = scan(cfg, result)
    actions = plan(files, cfg, result)
    execute(actions, cfg, result)
    result.duration = time.perf_counter() - start
    log.info(
        "Finished: moved=%d duplicates=%d skipped=%d errors=%d",
        len(result.moved), len(result.duplicates), len(result.skipped), len(result.errors),
    )
    return result


# ------------------------------------------------------------------------ undo
def _prune_empty(directory: Path, stop: Path) -> None:
    while directory != stop and stop in directory.parents:
        try:
            directory.rmdir()  # only succeeds when empty
        except OSError:
            return
        directory = directory.parent


def undo_last(dest: Path, dry_run: bool = False) -> Result:
    hist = dest / HISTORY_DIR
    manifests = sorted(hist.glob("run_*.json")) if hist.is_dir() else []
    if not manifests:
        raise UndoError(f"Nothing to undo in {dest}")
    manifest = manifests[-1]
    start = time.perf_counter()
    result = Result(title="Undo", moved_label="Restored", dry_run=dry_run)
    try:
        moves = json.loads(manifest.read_text(encoding="utf-8"))["moves"]
    except (OSError, ValueError, KeyError) as exc:
        raise UndoError(f"Undo manifest {manifest.name} is unreadable: {exc}")

    prefix = "[DRY-RUN] " if dry_run else ""
    for entry in reversed(moves):
        src, dst = Path(entry["src"]), Path(entry["dst"])
        if not dst.exists():
            result.errors.append((dst, "file no longer exists, cannot restore"))
            log.error("Undo: %s is gone", dst)
        elif src.exists():
            result.errors.append((src, "original location is occupied, left in place"))
            log.error("Undo: %s already exists", src)
        else:
            try:
                if not dry_run:
                    src.parent.mkdir(parents=True, exist_ok=True)
                    shutil.move(str(dst), str(src))
                    _prune_empty(dst.parent, dest)
                result.moved.append((dst, src))
                log.info("%sRESTORE %s -> %s", prefix, dst.name, src)
            except (OSError, shutil.Error) as exc:
                result.errors.append((dst, f"{type(exc).__name__}: {exc}"))
                log.error("Undo failed for %s: %s", dst, exc)
    if not dry_run:
        try:
            manifest.rename(manifest.with_suffix(".undone"))
        except OSError as exc:
            log.error("Could not retire manifest %s: %s", manifest.name, exc)
    result.duration = time.perf_counter() - start
    return result
