"""Notifications: console summary and optional email."""
from __future__ import annotations

import logging
import os
import smtplib
from email.message import EmailMessage

log = logging.getLogger("organizer")


def send_email(ecfg: dict, subject: str, body: str) -> bool:
    """Send a plain-text email. Never raises: failures are logged and False is returned."""
    msg = EmailMessage()
    msg["Subject"] = subject
    msg["From"] = ecfg["from_addr"]
    msg["To"] = ", ".join(ecfg["to_addrs"])
    msg.set_content(body)
    password = os.environ.get(ecfg["password_env"], "")
    try:
        with smtplib.SMTP(ecfg["smtp_host"], ecfg["smtp_port"], timeout=15) as server:
            if ecfg["use_tls"]:
                server.starttls()
            if ecfg["username"]:
                server.login(ecfg["username"], password)
            server.send_message(msg)
        log.info("Notification email sent to %s", msg["To"])
        return True
    except (smtplib.SMTPException, OSError) as exc:
        log.error("Could not send notification email: %s", exc)
        return False


def notify(cfg: dict, result) -> None:
    text = result.summary()
    if cfg["notify"]["console"]:
        print(text)
    email = cfg["notify"]["email"]
    if email["enabled"] and not result.dry_run:
        if result.has_activity or not email["only_on_activity"]:
            status = "with errors" if result.errors else "ok"
            send_email(email, f"[File Organizer] {result.title} {status}: {len(result.moved)} moved", text)
