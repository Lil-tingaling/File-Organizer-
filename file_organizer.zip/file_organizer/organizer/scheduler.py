"""Simple built-in scheduler (for cron / Task Scheduler see the README)."""
from __future__ import annotations

import logging
import time

log = logging.getLogger("organizer")


def run_every(minutes: float, job, max_runs: int | None = None, sleep=time.sleep) -> int:
    """Run job() now and then every `minutes`. A failing run never stops the schedule.
    Stops after max_runs (if given) or on Ctrl+C. Returns the number of runs."""
    runs = 0
    try:
        while True:
            try:
                job()
            except Exception:  # noqa: BLE001 - keep the schedule alive
                log.exception("Scheduled run failed; will retry at the next interval")
            runs += 1
            if max_runs is not None and runs >= max_runs:
                return runs
            log.info("Next run in %s minute(s). Press Ctrl+C to stop.", minutes)
            sleep(minutes * 60)
    except KeyboardInterrupt:
        log.info("Scheduler stopped by user after %d run(s)", runs)
        return runs
