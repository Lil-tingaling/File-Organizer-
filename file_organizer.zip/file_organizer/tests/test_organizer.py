import json
import os
import smtplib
import time
from pathlib import Path

import pytest

from organizer import notify as notify_mod
from organizer.cli import main
from organizer.config import ConfigError, load_config
from organizer.core import HISTORY_DIR, UndoError, organize, undo_last
from organizer.scheduler import run_every

OLD = time.mktime((2024, 3, 15, 12, 0, 0, 0, 0, -1))  # 15 Mar 2024
OLDER = OLD - 86400 * 40                                # Feb 2024


def make(root: Path, files: dict, mtime=OLD) -> Path:
    for rel, content in files.items():
        p = root / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(content if isinstance(content, bytes) else content.encode())
        os.utime(p, (mtime, mtime))
    return root


def cfg_for(src, **kw):
    return load_config(None, {"source": str(src), **kw})


def listing(root: Path):
    return sorted(str(p.relative_to(root)) for p in root.rglob("*") if HISTORY_DIR not in p.parts)


# ----------------------------------------------------------------- organizing
def test_sorts_by_type_case_insensitive(tmp_path):
    make(tmp_path, {"a.JPG": "1", "b.pdf": "2", "c.mp3": "3", "d.weird": "4", "noext": "5"})
    r = organize(cfg_for(tmp_path))
    assert len(r.moved) == 5 and not r.errors
    assert listing(tmp_path) == sorted([
        "Images", "Images/a.JPG", "Documents", "Documents/b.pdf", "Audio", "Audio/c.mp3",
        "Other", "Other/d.weird", "Other/noext",
    ])


def test_by_date_and_type_date(tmp_path):
    make(tmp_path, {"a.jpg": "1"}, mtime=OLD)
    make(tmp_path, {"b.jpg": "2"}, mtime=OLDER)
    organize(cfg_for(tmp_path, organize_by="date"))
    assert (tmp_path / "2024-03" / "a.jpg").exists() and (tmp_path / "2024-02" / "b.jpg").exists()

    other = tmp_path / "second"
    other.mkdir()
    make(other, {"c.png": "3"})
    organize(cfg_for(other, organize_by="type_date"))
    assert (other / "Images" / "2024-03" / "c.png").exists()


def test_dry_run_changes_nothing(tmp_path):
    make(tmp_path, {"a.jpg": "1", "b.txt": "2", "c.jpg": "1"})
    before = sorted(str(p) for p in tmp_path.rglob("*"))
    r = organize(cfg_for(tmp_path), dry_run=True)
    assert len(r.moved) + len(r.duplicates) == 3
    assert before == sorted(str(p) for p in tmp_path.rglob("*"))  # incl. no history folder


def test_name_clash_never_overwrites(tmp_path):
    make(tmp_path, {"Images/a.jpg": "original"})
    make(tmp_path, {"a.jpg": "different"})
    organize(cfg_for(tmp_path))
    assert (tmp_path / "Images" / "a.jpg").read_text() == "original"
    assert (tmp_path / "Images" / "a_1.jpg").read_text() == "different"


def test_two_new_files_same_target_name_in_one_run(tmp_path):
    make(tmp_path, {"x/a.jpg": "one", "y/a.jpg": "two"})
    r = organize(cfg_for(tmp_path, recursive=True))
    assert not r.errors
    assert sorted(p.name for p in (tmp_path / "Images").iterdir()) == ["a.jpg", "a_1.jpg"]


def test_ignores_hidden_temp_and_directories(tmp_path):
    make(tmp_path, {".hidden": "x", "dl.tmp": "x", "Thumbs.db": "x", "real.txt": "x", "keepdir/inner.txt": "x"})
    r = organize(cfg_for(tmp_path))
    assert len(r.moved) == 1
    assert (tmp_path / ".hidden").exists() and (tmp_path / "dl.tmp").exists()
    assert (tmp_path / "keepdir" / "inner.txt").exists()  # not recursive


def test_min_age_skips_fresh_files(tmp_path):
    make(tmp_path, {"old.txt": "1"}, mtime=OLD)
    make(tmp_path, {"fresh.txt": "2"}, mtime=time.time())
    r = organize(cfg_for(tmp_path, min_age_seconds=3600))
    assert [p.name for p, _ in r.moved] == ["old.txt"]
    assert (tmp_path / "fresh.txt").exists()
    assert any(reason == "modified too recently" for _, reason in r.skipped)


def test_symlinks_are_skipped(tmp_path):
    make(tmp_path, {"real.txt": "x"})
    try:
        (tmp_path / "link.txt").symlink_to(tmp_path / "real.txt")
    except OSError:
        pytest.skip("symlinks not supported")
    r = organize(cfg_for(tmp_path))
    assert (tmp_path / "link.txt").is_symlink()
    assert any(reason == "symlink" for _, reason in r.skipped)


def test_separate_destination(tmp_path):
    src, dest = tmp_path / "src", tmp_path / "out"
    src.mkdir()
    make(src, {"a.jpg": "1"})
    organize(cfg_for(src, destination=str(dest)))
    assert (dest / "Images" / "a.jpg").exists() and not (src / "a.jpg").exists()


# ------------------------------------------------------------------ recursion
def test_recursive_and_idempotent(tmp_path):
    make(tmp_path, {"top.jpg": "1", "sub/deep/b.pdf": "2", "sub/c.jpg": "3"})
    cfg = cfg_for(tmp_path, recursive=True)
    first = organize(cfg)
    assert len(first.moved) == 3
    second = organize(cfg)
    assert not second.moved and not second.duplicates and not second.errors
    assert (tmp_path / "Documents" / "b.pdf").exists()


def test_recursive_date_mode_is_idempotent_with_rename(tmp_path):
    make(tmp_path, {"a.jpg": "1", "sub/b.jpg": "2"})
    cfg = cfg_for(tmp_path, recursive=True, organize_by="date", rename_pattern="{date}_{name}")
    organize(cfg)
    names = sorted(p.name for p in (tmp_path / "2024-03").iterdir())
    assert names == ["2024-03-15_a.jpg", "2024-03-15_b.jpg"]
    assert not organize(cfg).moved  # no double renaming


def test_emptied_folders_removed_but_others_kept_and_undo_restores(tmp_path):
    make(tmp_path, {"a/b/c.jpg": "1", "keep/d.txt": "2", "keep/.secret": "x"})
    (tmp_path / "empty_already").mkdir()
    organize(cfg_for(tmp_path, recursive=True))
    assert not (tmp_path / "a").exists()              # emptied by our move -> removed
    assert (tmp_path / "keep" / ".secret").exists()   # still has content -> kept
    assert (tmp_path / "empty_already").exists()      # was never ours -> untouched
    undo_last(tmp_path)
    assert (tmp_path / "a" / "b" / "c.jpg").exists() and (tmp_path / "keep" / "d.txt").exists()


# ----------------------------------------------------------------- duplicates
def test_duplicates_oldest_kept(tmp_path):
    make(tmp_path, {"orig.jpg": "same bytes"}, mtime=OLDER)
    make(tmp_path, {"copy.jpg": "same bytes", "unique.jpg": "other"}, mtime=OLD)
    r = organize(cfg_for(tmp_path))
    assert (tmp_path / "Images" / "orig.jpg").exists()
    assert (tmp_path / "Duplicates" / "copy.jpg").exists()
    assert (tmp_path / "Images" / "unique.jpg").exists()
    assert len(r.duplicates) == 1 and "orig.jpg" in r.duplicates[0][2]


def test_duplicates_skip_mode_leaves_file(tmp_path):
    make(tmp_path, {"a.jpg": "same", "b.jpg": "same"})
    organize(cfg_for(tmp_path, duplicates="skip"))
    assert (tmp_path / "Images" / "a.jpg").exists() and (tmp_path / "b.jpg").exists()
    assert not (tmp_path / "Duplicates").exists()


def test_duplicate_of_already_organized_file(tmp_path):
    make(tmp_path, {"a.jpg": "payload"})
    organize(cfg_for(tmp_path))
    make(tmp_path, {"a.jpg": "payload"})       # same name, same content, arrives later
    r = organize(cfg_for(tmp_path))
    assert len(r.duplicates) == 1 and (tmp_path / "Duplicates" / "a.jpg").exists()


def test_empty_files_are_not_duplicates(tmp_path):
    make(tmp_path, {"a.txt": "", "b.txt": ""})
    r = organize(cfg_for(tmp_path))
    assert not r.duplicates and len(r.moved) == 2


# --------------------------------------------------------------------- rename
def test_rename_pattern(tmp_path):
    make(tmp_path, {"photo.JPG": "1", "doc.pdf": "2"})
    organize(cfg_for(tmp_path, rename_pattern="{date}_{counter}_{name}"))
    # counters follow alphabetical order of the original names
    assert (tmp_path / "Documents" / "2024-03-15_001_doc.pdf").exists()
    assert (tmp_path / "Images" / "2024-03-15_002_photo.JPG").exists()


# ------------------------------------------------------------ error handling
def test_one_failure_does_not_stop_run(tmp_path, monkeypatch):
    make(tmp_path, {"good.jpg": "1", "bad.jpg": "2", "also_good.txt": "3"})
    import organizer.core as core
    real_move = core.shutil.move

    def flaky(src, dst):
        if Path(src).name == "bad.jpg":
            raise PermissionError("access denied")
        return real_move(src, dst)

    monkeypatch.setattr(core.shutil, "move", flaky)
    r = organize(cfg_for(tmp_path))
    assert len(r.moved) == 2 and len(r.errors) == 1
    assert "access denied" in r.errors[0][1]
    assert (tmp_path / "bad.jpg").exists()          # untouched
    assert "bad.jpg" in r.summary()


# ----------------------------------------------------------------------- undo
def test_undo_restores_everything(tmp_path):
    make(tmp_path, {"a.jpg": "1", "b.txt": "2", "c.jpg": "1", "sub/d.mp3": "4"})
    before = listing(tmp_path)
    organize(cfg_for(tmp_path, recursive=True))
    assert listing(tmp_path) != before
    r = undo_last(tmp_path)
    assert not r.errors and len(r.moved) == 4
    assert listing(tmp_path) == before              # incl. empty folders removed


def test_undo_only_last_run_and_repeatable(tmp_path):
    make(tmp_path, {"a.jpg": "1"})
    organize(cfg_for(tmp_path))
    make(tmp_path, {"b.txt": "2"})
    organize(cfg_for(tmp_path))
    undo_last(tmp_path)
    assert (tmp_path / "b.txt").exists() and (tmp_path / "Images" / "a.jpg").exists()
    undo_last(tmp_path)
    assert (tmp_path / "a.jpg").exists()
    with pytest.raises(UndoError):
        undo_last(tmp_path)


def test_undo_conflicts_reported_not_overwritten(tmp_path):
    make(tmp_path, {"a.jpg": "1", "b.jpg": "2"})
    organize(cfg_for(tmp_path))
    make(tmp_path, {"a.jpg": "NEW FILE"})           # something now occupies the old spot
    r = undo_last(tmp_path)
    assert len(r.errors) == 1 and len(r.moved) == 1
    assert (tmp_path / "a.jpg").read_text() == "NEW FILE"
    assert (tmp_path / "Images" / "a.jpg").exists()


def test_undo_nothing(tmp_path):
    with pytest.raises(UndoError):
        undo_last(tmp_path)


def test_undo_dry_run(tmp_path):
    make(tmp_path, {"a.jpg": "1"})
    organize(cfg_for(tmp_path))
    r = undo_last(tmp_path, dry_run=True)
    assert len(r.moved) == 1 and (tmp_path / "Images" / "a.jpg").exists()
    undo_last(tmp_path)                              # manifest was not consumed
    assert (tmp_path / "a.jpg").exists()


# --------------------------------------------------------------------- config
@pytest.mark.parametrize("overrides, text", [
    ({"organize_by": "colour"}, "organize_by"),
    ({"duplicates": "delete"}, "duplicates"),
    ({"rename_pattern": "{bogus}"}, "placeholder"),
    ({"rename_pattern": "{name"}, "rename_pattern"),
    ({"rename_pattern": "{name.__class__}"}, "placeholder"),
    ({"date_format": "%Y/%m"}, "date_format"),
    ({"min_age_seconds": -5}, "min_age_seconds"),
    ({"categories": {"Pics": ["jpg"]}}, "extension"),
    ({"categories": {"A": [".x"], "B": [".x"]}}, "both"),
    ({"categories": {"../evil": [".x"]}}, "folder name"),
    ({"other_folder": "Duplicates"}, "different"),
    ({"recursive": "yes"}, "recursive"),
    ({"notify": {"email": {"enabled": True}}}, "Email"),
])
def test_invalid_config(tmp_path, overrides, text):
    with pytest.raises(ConfigError) as exc:
        cfg_for(tmp_path, **overrides)
    assert text.lower() in str(exc.value).lower()


def test_missing_source_and_bad_files(tmp_path):
    with pytest.raises(ConfigError):
        load_config(None, {})
    with pytest.raises(ConfigError):
        load_config(None, {"source": str(tmp_path / "nope")})
    with pytest.raises(ConfigError):
        load_config(tmp_path / "missing.json", {"source": str(tmp_path)})
    bad = tmp_path / "bad.json"
    bad.write_text("{not json")
    with pytest.raises(ConfigError):
        load_config(bad, {"source": str(tmp_path)})
    typo = tmp_path / "typo.json"
    typo.write_text('{"organise_by": "type"}')
    with pytest.raises(ConfigError, match="Unknown"):
        load_config(typo, {"source": str(tmp_path)})


def test_config_file_and_cli_override_precedence(tmp_path):
    cfgfile = tmp_path / "c.json"
    cfgfile.write_text(json.dumps({"organize_by": "date", "other_folder": "Misc",
                                   "categories": {"Pics": [".jpg"]}}))
    cfg = load_config(cfgfile, {"source": str(tmp_path), "organize_by": "type"})
    assert cfg["organize_by"] == "type"            # CLI beats file
    assert cfg["other_folder"] == "Misc"           # file beats default
    assert list(cfg["categories"]) == ["Pics"]     # categories replaced, not merged


# ----------------------------------------------------------------- notifications
class FakeSMTP:
    sent, fail = [], False

    def __init__(self, host, port, timeout=None):
        if FakeSMTP.fail:
            raise ConnectionRefusedError("smtp down")
        self.host = host

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False

    def starttls(self):
        pass

    def login(self, user, pw):
        FakeSMTP.login_args = (user, pw)

    def send_message(self, msg):
        FakeSMTP.sent.append(msg)


def email_cfg(tmp_path):
    return cfg_for(tmp_path, notify={"email": {
        "enabled": True, "smtp_host": "smtp.test", "from_addr": "me@test.com",
        "to_addrs": ["you@test.com"], "username": "me@test.com"}})


def test_email_sent_with_password_from_env(tmp_path, monkeypatch):
    FakeSMTP.sent, FakeSMTP.fail = [], False
    monkeypatch.setattr(smtplib, "SMTP", FakeSMTP)
    monkeypatch.setenv("ORGANIZER_SMTP_PASSWORD", "s3cret")
    make(tmp_path, {"a.jpg": "1"})
    cfg = email_cfg(tmp_path)
    notify_mod.notify(cfg, organize(cfg))
    assert len(FakeSMTP.sent) == 1 and "1 moved" in FakeSMTP.sent[0]["Subject"]
    assert FakeSMTP.login_args == ("me@test.com", "s3cret")


def test_email_skipped_when_idle_or_dry_run_and_failure_is_safe(tmp_path, monkeypatch):
    FakeSMTP.sent, FakeSMTP.fail = [], False
    monkeypatch.setattr(smtplib, "SMTP", FakeSMTP)
    cfg = email_cfg(tmp_path)
    notify_mod.notify(cfg, organize(cfg))                       # nothing to do -> no mail
    make(tmp_path, {"a.jpg": "1"})
    notify_mod.notify(cfg, organize(cfg, dry_run=True))         # dry run -> no mail
    assert FakeSMTP.sent == []
    FakeSMTP.fail = True
    notify_mod.notify(cfg, organize(cfg))                       # SMTP down -> no crash
    assert (tmp_path / "Images" / "a.jpg").exists()


# -------------------------------------------------------------------- scheduler
def test_scheduler_runs_survives_errors_and_stops():
    calls, sleeps = [], []

    def job():
        calls.append(1)
        if len(calls) == 2:
            raise RuntimeError("boom")

    assert run_every(5, job, max_runs=4, sleep=sleeps.append) == 4
    assert len(calls) == 4 and sleeps == [300, 300, 300]


def test_scheduler_ctrl_c_stops_cleanly():
    def interrupt(_):
        raise KeyboardInterrupt

    assert run_every(1, lambda: None, sleep=interrupt) == 1


# -------------------------------------------------------------------------- CLI
def test_cli_end_to_end_and_undo(tmp_path, capsys):
    make(tmp_path, {"a.jpg": "1", "b.pdf": "2"})
    assert main([str(tmp_path)]) == 0
    assert "Moved:" in capsys.readouterr().out
    assert (tmp_path / HISTORY_DIR / "organizer.log").exists()
    assert "MOVE a.jpg" in (tmp_path / HISTORY_DIR / "organizer.log").read_text()
    assert main([str(tmp_path), "--undo"]) == 0
    assert (tmp_path / "a.jpg").exists() and (tmp_path / "b.pdf").exists()


def test_cli_dry_run_writes_nothing(tmp_path, capsys):
    make(tmp_path, {"a.jpg": "1"})
    assert main([str(tmp_path), "--dry-run", "-v"]) == 0
    out = capsys.readouterr()
    assert "DRY RUN" in out.out and "[DRY-RUN] MOVE a.jpg" in out.err
    assert listing(tmp_path) == ["a.jpg"] and not (tmp_path / HISTORY_DIR).exists()


def test_cli_exit_codes(tmp_path, capsys):
    assert main([str(tmp_path / "missing")]) == 2
    assert "Configuration error" in capsys.readouterr().err
    assert main([str(tmp_path), "--undo"]) == 1          # nothing to undo
    with pytest.raises(SystemExit) as e:
        main([str(tmp_path), "--every", "0"])
    assert e.value.code == 2
    with pytest.raises(SystemExit):
        main([str(tmp_path), "--by", "nonsense"])


def test_cli_returns_1_when_errors(tmp_path, monkeypatch, capsys):
    make(tmp_path, {"a.jpg": "1"})
    import organizer.core as core
    monkeypatch.setattr(core.shutil, "move", lambda *a: (_ for _ in ()).throw(OSError("disk full")))
    assert main([str(tmp_path)]) == 1
    assert "disk full" in capsys.readouterr().out


def test_cli_with_config_file_and_flags(tmp_path):
    src = tmp_path / "s"
    src.mkdir()
    make(src, {"a.jpg": "1"})
    cfgfile = tmp_path / "cfg.json"
    cfgfile.write_text(json.dumps({"source": str(src), "organize_by": "date"}))
    assert main(["-c", str(cfgfile)]) == 0
    assert (src / "2024-03" / "a.jpg").exists()
