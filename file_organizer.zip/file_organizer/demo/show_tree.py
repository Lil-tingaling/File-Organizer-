#!/usr/bin/env python3
"""Print a folder as a tree (hides the .organizer_history folder).  Usage: python demo/show_tree.py FOLDER"""
import sys
from pathlib import Path


def tree(root: Path, prefix: str = ""):
    items = sorted((p for p in root.iterdir() if p.name != ".organizer_history"), key=lambda p: (p.is_file(), p.name.lower()))
    for i, item in enumerate(items):
        last = i == len(items) - 1
        print(f"{prefix}{'└── ' if last else '├── '}{item.name}{'/' if item.is_dir() else ''}")
        if item.is_dir():
            tree(item, prefix + ("    " if last else "│   "))


root = Path(sys.argv[1])
print(f"{root.name}/")
tree(root)
