#!/usr/bin/env python3
"""Create a realistic messy folder to try the organizer on.

Usage: python demo/make_messy_folder.py [target_folder]
"""
import os
import sys
import time
from pathlib import Path

target = Path(sys.argv[1] if len(sys.argv) > 1 else "demo_messy")
DAY = 86400
now = time.time()

# (relative path, content, age in days)
FILES = [
    ("holiday.jpg", "photo-bytes-A", 120),
    ("holiday_copy.jpg", "photo-bytes-A", 60),          # duplicate of holiday.jpg
    ("Screenshot 2024.PNG", "png-bytes", 45),
    ("logo.svg", "<svg/>", 200),
    ("report.pdf", "q3 report v2", 30),
    ("notes.txt", "meeting notes", 15),
    ("budget.xlsx", "budget numbers", 95),
    ("song.mp3", "mp3-bytes", 300),
    ("clip.mp4", "mp4-bytes" * 50, 20),
    ("backup.zip", "zip-bytes", 70),
    ("setup.exe", "exe-bytes", 10),
    ("script.py", "print('hi')", 5),
    ("data.json", "{}", 5),
    ("mystery.xyz", "???", 40),
    ("README", "no extension", 40),
    (".hidden_settings", "ignored", 40),                 # ignored: hidden
    ("download.crdownload", "partial", 0),                # ignored: unfinished download
    ("old_stuff/report.pdf", "q1 report v1", 250),       # name clash with report.pdf
    ("old_stuff/photo.jpg", "photo-bytes-A", 400),       # another copy (oldest = kept)
    ("old_stuff/deep/archive.tar", "tar-bytes", 330),
]

for rel, content, age_days in FILES:
    path = target / rel
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content)
    t = now - age_days * DAY
    os.utime(path, (t, t))

print(f"Created {len(FILES)} files in {target}/")
