# File Organizer - Report

## 1. Problem statement
Download folders and shared drives fill up with unsorted files: photos next to installers, PDFs with clashing names, the same file saved three times, half-finished downloads. Cleaning this by hand is slow, repetitive and risky (it is easy to overwrite or lose a file). The goal was a tool that does this safely and repeatably, can run unattended on a schedule, tells the user what it did, and can reverse its work.

## 2. Solution approach
A Python command-line tool using only the standard library.

**Pipeline.** `scan` collects candidate files, `plan` decides the destination of each one without touching the disk, and `execute` performs the moves. Separating planning from execution gives dry runs and undo almost for free.

**Key decisions**
| Decision | Why |
|---|---|
| Never overwrite, never delete | Name clashes get `_1`, `_2`; duplicates go to a `Duplicates/` folder. A mistake is always recoverable. |
| Duplicate detection by content | Group by file size first (cheap), hash only same-size files with SHA-256. The oldest copy is kept. Empty files are not treated as duplicates. |
| Undo manifest | Every real run saves a JSON list of moves; `--undo` replays it backwards and refuses to overwrite anything. |
| Config precedence | built-in defaults < JSON config file < command-line flags. Unknown keys are rejected so typos are caught. |
| Per-file error handling | A failure on one file is logged and reported, and the rest of the run continues. Exit code is `1` if anything failed. |
| Idempotent runs | Folders the tool creates are skipped when scanning, so repeated or scheduled runs never re-process or double-rename files. |
| Secrets | The SMTP password is read from an environment variable, never from the config file. |
| Scheduler | A built-in `--every N` loop (a failing run does not kill the schedule) plus documented cron / Task Scheduler setups. |

**Requirement coverage**
| Brief | Implementation |
|---|---|
| Real problem | Organizing and renaming messy folders, removing duplicate clutter |
| Accept inputs / config file | JSON config + CLI arguments |
| Log execution results | Rotating log file with every action, plus console summary |
| Handle errors safely | Validation, per-file isolation, no overwrite/delete, undo, exit codes |
| Command-line arguments | `argparse` interface (see README) |
| Scheduling | `--every`, cron, Windows Task Scheduler |
| Notifications | Console summary and email (SMTP) |
| Test multiple scenarios, validate outputs | 47 automated tests + the demo below |

## 3. Demonstration results
A practice folder with 20 files was generated: images, documents, audio/video, archives, an installer, code files, an unknown type, a file with no extension, a hidden file, an unfinished download, a duplicate photo (in two places), and two different `report.pdf` files (one in a subfolder).

**Before**
```
$ python demo/make_messy_folder.py demo_messy
Created 20 files in demo_messy/

$ python demo/show_tree.py demo_messy
demo_messy/
├── old_stuff/
│   ├── deep/
│   │   └── archive.tar
│   ├── photo.jpg
│   └── report.pdf
├── .hidden_settings
├── backup.zip
├── budget.xlsx
├── clip.mp4
├── data.json
├── download.crdownload
├── holiday.jpg
├── holiday_copy.jpg
├── logo.svg
├── mystery.xyz
├── notes.txt
├── README
├── report.pdf
├── Screenshot 2024.PNG
├── script.py
├── setup.exe
└── song.mp3
```

**Preview (dry run).** Nothing is changed.
```
$ python organize.py demo_messy --recursive --dry-run
File Organizer: DRY RUN - no files were changed in 0.00s
  Moved:      16
  Duplicates: 2
  Skipped:    0
  Errors:     0
  By category:
    Archives: 2
    Audio: 1
    Code: 2
    Documents: 4
    Images: 3
    Installers: 1
    Other: 2
    Videos: 1
```

**Real run and result**
```
$ python organize.py demo_messy --recursive
File Organizer: finished in 0.01s
  Moved:      16
  Duplicates: 2
  Skipped:    0
  Errors:     0
  By category:
    Archives: 2
    Audio: 1
    Code: 2
    Documents: 4
    Images: 3
    Installers: 1
    Other: 2
    Videos: 1

$ python demo/show_tree.py demo_messy
demo_messy/
├── Archives/
│   ├── archive.tar
│   └── backup.zip
├── Audio/
│   └── song.mp3
├── Code/
│   ├── data.json
│   └── script.py
├── Documents/
│   ├── budget.xlsx
│   ├── notes.txt
│   ├── report.pdf
│   └── report_1.pdf
├── Duplicates/
│   ├── holiday.jpg
│   └── holiday_copy.jpg
├── Images/
│   ├── logo.svg
│   ├── photo.jpg
│   └── Screenshot 2024.PNG
├── Installers/
│   └── setup.exe
├── Other/
│   ├── mystery.xyz
│   └── README
├── Videos/
│   └── clip.mp4
├── .hidden_settings
└── download.crdownload
```
Observations: all three copies of the same photo were detected, the oldest (`photo.jpg`) was kept and the other two moved to `Duplicates/`. The two different `report.pdf` files were both kept (`report.pdf`, `report_1.pdf`). The hidden file and the unfinished download were left alone. The empty `old_stuff/` folders were cleaned up.

**Running again changes nothing, and everything is logged**
```
$ python organize.py demo_messy --recursive      # run again
File Organizer: finished in 0.00s
  Moved:      0
  Duplicates: 0
  Skipped:    0
  Errors:     0

$ cat demo_messy/.organizer_history/organizer.log   (excerpt)
2026-10-30 21:24:49,988 INFO    Starting run: source=demo_messy destination=demo_messy mode=type
2026-10-30 21:24:49,990 INFO    MOVE backup.zip -> Archives/backup.zip
2026-10-30 21:24:49,990 INFO    MOVE budget.xlsx -> Documents/budget.xlsx
2026-10-30 21:24:49,991 INFO    MOVE clip.mp4 -> Videos/clip.mp4
2026-10-30 21:24:49,993 INFO    MOVE script.py -> Code/script.py
2026-10-30 21:24:49,993 INFO    MOVE setup.exe -> Installers/setup.exe
2026-10-30 21:24:49,993 INFO    MOVE song.mp3 -> Audio/song.mp3
```

**Undo**
```
$ python organize.py demo_messy --undo
Undo: finished in 0.00s
  Restored:   18
  Errors:     0
```
All 18 files returned to their original locations, including the nested `old_stuff/deep/` folder.

**Other modes** (sort by type and date, rename with a pattern, leave duplicates in place)
```
$ python organize.py demo_messy --by type_date --rename "{date}_{name}" --duplicates skip
File Organizer: finished in 0.01s
  Moved:      14
  Duplicates: 0
  Skipped:    1
  Errors:     0
  By category:
    Archives: 1
    Audio: 1
    Code: 2
    Documents: 3
    Images: 3
    Installers: 1
    Other: 2
    Videos: 1
demo2/
├── Archives/
│   └── 2026-08/
│       └── 2026-08-21_backup.zip
├── Audio/
│   └── 2026-01/
│       └── 2026-01-03_song.mp3
├── Code/
│   └── 2026-10/
│       ├── 2026-10-25_data.json
│       └── 2026-10-25_script.py
├── Documents/
│   ├── 2026-07/
│   │   └── 2026-07-27_budget.xlsx
...
```

**Scheduling.** The tool ran every 3 seconds; a new file dropped into the folder while it was running was picked up on the next run, and Ctrl+C stopped it cleanly.
```
$ python organize.py demo_folder --every 0.05 -v      # every 3 seconds, stopped with Ctrl+C
INFO: MOVE first.txt -> Documents/first.txt
  Moved:      1
INFO: Next run in 0.05 minute(s). Press Ctrl+C to stop.
  Moved:      0
INFO: Next run in 0.05 minute(s). Press Ctrl+C to stop.
INFO: MOVE dropped_later.png -> Images/dropped_later.png
  Moved:      1
INFO: Next run in 0.05 minute(s). Press Ctrl+C to stop.
INFO: Scheduler stopped by user after 3 run(s)
```

**Error handling and validation**
```
$ python organize.py demo_messy --by colour
organize.py: error: argument --by: invalid choice: 'colour' (choose from 'type', 'date', 'type_date')
$ python organize.py /nonexistent; echo "exit=$?"
Configuration error: Source folder does not exist: /nonexistent
exit=2
$ python organize.py demo_messy --rename "{oops}"; echo "exit=$?"
Configuration error: Unknown placeholder(s) in rename_pattern: ['oops']. Allowed: {name}, {ext}, {date}, {counter}
exit=2
```

## 4. Testing
47 automated tests (`pytest`, all passing) cover:
- **Sorting:** by type (case-insensitive extensions), by date, by type+date, separate destination folder, unknown/no-extension files
- **Safety:** dry run changes nothing; name clashes never overwrite (including two new files with the same name in one run); hidden, temp and recent files ignored; symlinks skipped
- **Duplicates:** oldest kept, `skip` mode, duplicates of already-organized files, empty files
- **Rename patterns**, recursive runs, idempotency (a second run does nothing, with and without rename)
- **Error handling:** a simulated "access denied" on one file does not stop the others and is reported
- **Undo:** full restore, only the last run, repeated undo, conflicts reported without overwriting, dry-run undo, nothing to undo
- **Configuration:** 13 invalid-config cases, unknown keys, missing files, precedence of defaults/file/CLI
- **Notifications:** email sent with password from the environment, not sent when idle or in dry run, SMTP failure does not crash the run (tested with a fake mail server)
- **Scheduler:** repeats, survives a failing run, stops on Ctrl+C
- **CLI:** end-to-end run and undo, exit codes `0/1/2`, invalid arguments

Run with `pytest -q`.

## 5. Limitations and possible improvements
- Dates use the file's modified time (not photo EXIF data).
- Developed and tested on Linux. Paths and moves use `pathlib`/`shutil`, so Windows and macOS should work, but this was not tested there. The email path was tested against a fake server, not a real mail provider.
- Undo only covers the most recent un-undone run each time (it can be repeated to go further back).
- Possible extensions: a "watch folder" mode using filesystem events, EXIF-based photo dates, and rules by file name or size.
