# File Organizer

A command-line tool that cleans up messy folders (like *Downloads*): it sorts files into folders by type and/or date, renames them with a pattern, moves duplicates aside, logs everything, and can **undo** any run. Standard library only, no dependencies.

## Features
- **Sort** by file type, by date, or both (`--by type|date|type_date`)
- **Bulk rename** with patterns like `{date}_{name}`
- **Duplicate detection** by content (size, then SHA-256); the oldest copy is kept
- **Config file** (JSON) + **command-line arguments** (CLI wins over file, file wins over defaults)
- **Dry run** to preview, and **undo** for the last run
- **Logging** to a rotating log file, **error handling** that never stops the whole run
- **Scheduling** built in (`--every N`) or via cron / Windows Task Scheduler
- **Notifications**: console summary and optional email

## Quick start
```bash
python --version                 # 3.9 or newer
python demo/make_messy_folder.py demo_messy      # make a practice folder
python organize.py demo_messy --recursive --dry-run   # preview
python organize.py demo_messy --recursive             # do it
python organize.py demo_messy --undo                  # put everything back
```

## Usage
```
python organize.py [SOURCE] [options]

  -c, --config FILE        JSON config file
  -d, --destination DIR    put organized folders here (default: inside SOURCE)
      --by {type,date,type_date}
  -r, --recursive          include subfolders
      --rename PATTERN     e.g. "{date}_{name}"  ({name} {ext} {date} {counter})
      --duplicates {move,skip}
      --min-age SECONDS    ignore files modified very recently (half-downloaded files)
  -n, --dry-run            show what would happen, change nothing
      --undo               undo the most recent run
      --every MINUTES      keep running every N minutes (Ctrl+C to stop)
      --email              send an email summary (see below)
      --log-file PATH      default: <destination>/.organizer_history/organizer.log
  -v, --verbose            print every action
```
Exit codes: `0` success, `1` finished with errors, `2` bad configuration or usage.

Examples:
```bash
python organize.py ~/Downloads --min-age 60
python organize.py ~/Downloads --by type_date --rename "{date}_{name}"
python organize.py -c config.json --every 30
```

## Configuration
Copy `config.example.json` and edit it. Unknown option names are rejected (so typos are caught). Main options:

| Option | Meaning | Default |
|---|---|---|
| `source`, `destination` | folders (destination defaults to source) | – |
| `organize_by` | `type`, `date`, `type_date` | `type` |
| `date_format` | folder name for date modes | `%Y-%m` |
| `categories` | `{"Folder": [".ext", ...]}` (replaces the built-in set) | 7 built-in categories |
| `other_folder` | for unknown extensions | `Other` |
| `duplicates` | `move` to a folder, or `skip` | `move` |
| `rename_pattern` | `{name}`, `{ext}`, `{date}`, `{counter}` | none |
| `ignore_patterns` | glob patterns to leave alone | hidden, `*.tmp`, `*.part`, `*.crdownload` ... |
| `min_age_seconds` | skip files modified more recently | `0` |
| `notify.email.*` | SMTP settings | disabled |

## How it stays safe
- Never overwrites: a name clash becomes `report_1.pdf`.
- Never deletes anything. Duplicates are moved to `Duplicates/`.
- Every real run saves a manifest in `.organizer_history/`; `--undo` restores the files (and recreates their folders). If something now occupies an original location, that file is left where it is and reported.
- Folders emptied by a recursive run are removed; folders that still contain anything are kept.
- Hidden files, temp/partial downloads and symlinks are skipped.
- A file that fails (permissions, disk full ...) is logged and reported; all other files are still processed.
- Re-running is harmless: organized folders are not scanned again.

## Scheduling
**Built in** (keep a terminal/service running): `python organize.py ~/Downloads --every 30`

**Linux/macOS cron** (`crontab -e`), every 30 minutes; use absolute paths:
```
*/30 * * * * /usr/bin/python3 /home/you/file_organizer/organize.py /home/you/Downloads --min-age 120
```
**Windows Task Scheduler** (run once, repeating every 30 minutes):
```
schtasks /Create /SC MINUTE /MO 30 /TN "FileOrganizer" /TR "python C:\tools\file_organizer\organize.py C:\Users\you\Downloads --min-age 120"
```

## Email notifications
1. In your config set `notify.email.enabled` to `true` and fill in `smtp_host`, `smtp_port`, `username`, `from_addr`, `to_addrs` (or use the `--email` flag once these are set).
2. Put the password in an **environment variable**, never in the file: `export ORGANIZER_SMTP_PASSWORD="app-password"` (Gmail needs an *app password*).
3. By default mail is only sent when something happened (`only_on_activity`) and never for dry runs. If the mail server is down, the run still succeeds and the failure is logged.

## Project structure
```
organize.py              entry point
organizer/
  cli.py                 argument parsing, exit codes
  config.py              defaults, file loading, validation
  core.py                scan -> plan -> execute, duplicates, undo
  notify.py              console + email notifications
  scheduler.py           --every loop
  logger.py              rotating file log
tests/test_organizer.py  47 tests
demo/                    messy-folder generator and tree viewer
config.example.json
REPORT.md                problem, approach, results
```
The three-step design (**scan** finds files, **plan** decides what should happen without touching anything, **execute** does it) is what makes dry runs and undo straightforward.

## Tests
```bash
pip install -r requirements-dev.txt
pytest -q
```
